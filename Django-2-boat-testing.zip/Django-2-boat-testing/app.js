'use strict';

/* Boat data receiver — multiplatform web app.
 * Connects a browser (PC / Mac / iPad / iPhone) directly to each boat's
 * WebSocket endpoint, and confirms data is flowing: per-boat connection
 * state, data rate, last-seen, decoded NMEA summary, and raw stream. */

const STORAGE_KEY = 'boat-receiver:boats:v1';
const MAX_LINES = 200;      // raw lines kept per boat
const LIVE_MS = 3000;       // connected but no data for this long -> "No data"
const RECONNECT_MAX_MS = 8000;
const ACCENTS = ['#37e0cf', '#ff8a5b', '#c084fc', '#7dd3fc'];

const panelsEl = document.getElementById('panels');
const waitingNote = document.getElementById('waiting-note');
const boatTpl = document.getElementById('boat-template');
const rowTpl = document.getElementById('row-template');

const boats = new Map(); // id -> runtime state

/* ---------- configuration persistence ---------- */
function loadConfig() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) return JSON.parse(raw);
  } catch (_) { /* ignore */ }
  return (window.DEFAULT_BOATS || []).map((b) => ({ ...b }));
}

function saveConfig(list) {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(list)); } catch (_) { /* ignore */ }
}

/* ---------- (re)build panels + connections from config ---------- */
function applyConfig(list) {
  // Tear down everything currently running
  for (const st of boats.values()) {
    st.closing = true;
    clearTimeout(st.timer);
    if (st.ws) { try { st.ws.close(); } catch (_) {} }
    st.el.remove();
  }
  boats.clear();

  if (!list.length) {
    if (!waitingNote.isConnected) panelsEl.appendChild(waitingNote);
    return;
  }
  if (waitingNote.isConnected) waitingNote.remove();

  list.forEach((def, i) => {
    const st = createPanel(def, i);
    boats.set(def.id, st);
    connectBoat(st);
  });
}

function createPanel(def, order) {
  const node = boatTpl.content.firstElementChild.cloneNode(true);
  node.dataset.boatId = def.id;
  node.querySelector('.boat__name').textContent = def.name || def.id;
  node.style.setProperty('--accent', ACCENTS[order % ACCENTS.length]);

  const st = {
    def,
    el: node,
    ws: null,
    conn: 'idle',    // idle | connecting | open | closed
    closing: false,
    retry: 0,
    timer: null,
    count: 0,
    lastTs: 0,
    times: [],
    parsed: {},
    paused: false,
    els: {
      state: node.querySelector('.boat__state'),
      src: node.querySelector('.src'),
      rate: node.querySelector('.rate'),
      count: node.querySelector('.count'),
      last: node.querySelector('.last'),
      summary: node.querySelector('.summary'),
      stream: node.querySelector('.stream'),
    },
  };
  node.querySelector('.pause-input').addEventListener('change', (e) => { st.paused = e.target.checked; });
  st.els.src.textContent = def.url || '—';
  panelsEl.appendChild(node);
  renderSummary(st);
  return st;
}

/* ---------- WebSocket connection per boat ---------- */
function connectBoat(st) {
  if (!st.def.url) { st.conn = 'idle'; return; }
  st.conn = 'connecting';
  let ws;
  try {
    ws = new WebSocket(st.def.url);
  } catch (_) {
    st.conn = 'closed';
    scheduleReconnect(st);
    return;
  }
  st.ws = ws;

  ws.onopen = () => { st.retry = 0; st.conn = 'open'; };
  ws.onmessage = (ev) => handleFrame(st, ev.data);
  ws.onerror = () => { try { ws.close(); } catch (_) {} };
  ws.onclose = () => {
    st.ws = null;
    st.conn = 'closed';
    scheduleReconnect(st);
  };
}

function scheduleReconnect(st) {
  if (st.closing) return;
  st.retry = Math.min(st.retry + 1, 6);
  const delay = Math.min(500 * 2 ** (st.retry - 1), RECONNECT_MAX_MS);
  clearTimeout(st.timer);
  st.timer = setTimeout(() => connectBoat(st), delay);
}

function handleFrame(st, data) {
  if (typeof data !== 'string') {
    if (typeof Blob !== 'undefined' && data instanceof Blob) {
      data.text().then((t) => handleFrame(st, t)).catch(() => {});
      return;
    }
    try { data = new TextDecoder().decode(data); } catch (_) { return; }
  }
  const ts = Date.now();
  const lines = data.split(/\r?\n/).map((s) => s.trim()).filter(Boolean);
  const emit = lines.length ? lines : [data.trim()];
  for (const line of emit) onData(st, line, ts);
}

function onData(st, raw, ts) {
  st.count += 1;
  st.lastTs = ts;
  st.times.push(ts);
  const cutoff = ts - 5000;
  while (st.times.length && st.times[0] < cutoff) st.times.shift();

  st.els.count.textContent = st.count.toLocaleString();

  st.el.classList.remove('is-hit');
  void st.el.offsetWidth;
  st.el.classList.add('is-hit');

  parseInto(st.parsed, raw);
  renderSummary(st);
  if (!st.paused) appendLine(st, raw, ts);
}

function appendLine(st, raw, ts) {
  const t = new Date(ts);
  const stamp = t.toTimeString().slice(0, 8) + '.' + String(t.getMilliseconds()).padStart(3, '0');

  const li = document.createElement('li');
  li.className = 'stream__line';
  const tsEl = document.createElement('span');
  tsEl.className = 'stream__t';
  tsEl.textContent = stamp;
  const rawEl = document.createElement('span');
  rawEl.className = 'stream__raw';
  rawEl.textContent = raw;
  li.append(tsEl, rawEl);

  st.els.stream.prepend(li);
  while (st.els.stream.children.length > MAX_LINES) {
    st.els.stream.removeChild(st.els.stream.lastChild);
  }
}

/* ---------- light NMEA 0183 decode for the summary chips ---------- */
function parseInto(p, raw) {
  if (!raw || (raw[0] !== '$' && raw[0] !== '!')) return;
  const star = raw.indexOf('*');
  const body = star >= 0 ? raw.slice(1, star) : raw.slice(1);
  const f = body.split(',');
  const type = (f[0] || '').slice(2);

  switch (type) {
    case 'RMC':
      setPos(p, f[3], f[4], f[5], f[6]);
      if (f[7]) p.sog = +f[7];
      if (f[8]) p.cog = +f[8];
      break;
    case 'GGA':
      setPos(p, f[2], f[3], f[4], f[5]);
      break;
    case 'GLL':
      setPos(p, f[1], f[2], f[3], f[4]);
      break;
    case 'VTG':
      if (f[1]) p.cog = +f[1];
      if (f[5]) p.sog = +f[5];
      break;
    case 'HDT':
    case 'HDG':
      if (f[1]) p.hdg = +f[1];
      break;
    case 'VHW':
      if (f[5]) p.bsp = +f[5];
      break;
    case 'MWV':
      if (f[2] === 'T') { if (f[1]) p.twa = +f[1]; if (f[3]) p.tws = +f[3]; }
      else { if (f[1]) p.awa = +f[1]; if (f[3]) p.aws = +f[3]; }
      break;
    case 'MWD':
      if (f[1]) p.twd = +f[1];
      if (f[5]) p.tws = +f[5];
      break;
  }
}

function setPos(p, latRaw, ns, lonRaw, ew) {
  const lat = toDecimal(latRaw, ns, 2);
  const lon = toDecimal(lonRaw, ew, 3);
  if (lat != null) p.lat = lat;
  if (lon != null) p.lon = lon;
}

function toDecimal(v, hemi, degDigits) {
  if (!v) return null;
  const deg = parseInt(v.slice(0, degDigits), 10);
  const min = parseFloat(v.slice(degDigits));
  if (Number.isNaN(deg) || Number.isNaN(min)) return null;
  let d = deg + min / 60;
  if (hemi === 'S' || hemi === 'W') d = -d;
  return d;
}

function renderSummary(st) {
  const p = st.parsed;
  const chips = [];
  if (p.lat != null && p.lon != null) chips.push(['Position', `${fmtCoord(p.lat, true)}  ${fmtCoord(p.lon, false)}`]);
  if (p.sog != null) chips.push(['SOG', `${p.sog.toFixed(1)} kn`]);
  if (p.cog != null) chips.push(['COG', `${Math.round(p.cog)}\u00b0`]);
  if (p.hdg != null) chips.push(['HDG', `${Math.round(p.hdg)}\u00b0`]);
  if (p.bsp != null) chips.push(['BSP', `${p.bsp.toFixed(1)} kn`]);
  if (p.tws != null) chips.push(['TWS', `${p.tws.toFixed(1)} kn`]);
  if (p.twd != null) chips.push(['TWD', `${Math.round(p.twd)}\u00b0`]);

  st.els.summary.innerHTML = '';
  if (!chips.length) {
    const d = document.createElement('div');
    d.className = 'summary__empty';
    d.textContent = 'No standard NMEA fields decoded yet. The raw stream below shows everything arriving on this connection.';
    st.els.summary.appendChild(d);
    return;
  }
  for (const [k, v] of chips) {
    const chip = document.createElement('div');
    chip.className = 'chip';
    const ck = document.createElement('span'); ck.className = 'chip__k'; ck.textContent = k;
    const cv = document.createElement('span'); cv.className = 'chip__v'; cv.textContent = v;
    chip.append(ck, cv);
    st.els.summary.appendChild(chip);
  }
}

function fmtCoord(dec, isLat) {
  const hemi = isLat ? (dec >= 0 ? 'N' : 'S') : (dec >= 0 ? 'E' : 'W');
  const a = Math.abs(dec);
  const deg = Math.floor(a);
  const min = (a - deg) * 60;
  return `${deg}\u00b0${min.toFixed(3)}'${hemi}`;
}

/* ---------- periodic refresh: rate + state pill ---------- */
setInterval(() => {
  const now = Date.now();
  for (const st of boats.values()) {
    const rate = st.times.filter((t) => t >= now - 1000).length;
    st.els.rate.innerHTML = `${rate}<em>/s</em>`;

    let state = 'idle', label = 'Idle';
    if (!st.def.url) { state = 'idle'; label = 'No URL'; }
    else if (st.conn === 'connecting') { state = 'connecting'; label = 'Connecting'; }
    else if (st.conn === 'closed') { state = 'down'; label = 'Offline'; }
    else if (st.conn === 'open') {
      const age = now - st.lastTs;
      if (!st.lastTs || age > LIVE_MS) { state = 'stale'; label = 'No data'; }
      else { state = 'live'; label = 'Live'; }
    }
    st.els.state.dataset.state = state;
    st.els.state.textContent = label;

    st.els.last.textContent = st.lastTs
      ? (now - st.lastTs < 1500 ? 'now' : `${Math.round((now - st.lastTs) / 1000)}s ago`)
      : '—';
  }
}, 500);

/* ---------- settings drawer ---------- */
const drawer = document.getElementById('drawer');
const boatRows = document.getElementById('boat-rows');
let editing = [];

function openDrawer() {
  editing = loadConfig().map((b) => ({ ...b }));
  boatRows.innerHTML = '';
  editing.forEach(addRow);
  drawer.hidden = false;
}
function closeDrawer() { drawer.hidden = true; }

function addRow(def) {
  const row = rowTpl.content.firstElementChild.cloneNode(true);
  const name = row.querySelector('.row__name');
  const url = row.querySelector('.row__url');
  name.value = def ? (def.name || '') : '';
  url.value = def ? (def.url || '') : '';
  row.querySelector('.row__remove').addEventListener('click', () => row.remove());
  boatRows.appendChild(row);
}

function collectRows() {
  const out = [];
  let n = 0;
  for (const row of boatRows.querySelectorAll('.row')) {
    const name = row.querySelector('.row__name').value.trim();
    const url = row.querySelector('.row__url').value.trim();
    if (!name && !url) continue;
    n += 1;
    out.push({ id: `boat${n}`, name: name || `Boat ${n}`, url });
  }
  return out;
}

document.getElementById('settings-btn').addEventListener('click', openDrawer);
document.getElementById('drawer-close').addEventListener('click', closeDrawer);
document.getElementById('drawer-scrim').addEventListener('click', closeDrawer);
document.getElementById('cancel-btn').addEventListener('click', closeDrawer);
document.getElementById('add-boat').addEventListener('click', () => addRow(null));
document.getElementById('save-btn').addEventListener('click', () => {
  const list = collectRows();
  saveConfig(list);
  applyConfig(list);
  closeDrawer();
});

/* ---------- start ---------- */
applyConfig(loadConfig());
