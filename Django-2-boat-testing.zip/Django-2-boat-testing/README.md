# Boat data receiver

Live navigation data from two boats, in one browser-based monitor that runs on
PC, Mac, iPad, and iPhone. This is step one: confirm the data arrives cleanly.
The real app gets built on the same feed later.

## Architecture

Expedition serves WebSockets only as a *client* (to pull data in from B&G
H5000), not as a server, and a browser can't connect to a raw TCP socket. So on
each boat's PC a small **bridge** takes Expedition's UDP output and re-serves it
as a WebSocket the web app can connect to. The bridge also serves the web app
over http, which sidesteps the browser's block on `https -> ws://`.

```
On each boat's PC:
  Expedition --UDP-> 127.0.0.1:5555 --> bridge --ws://this-pc:8080--> web app
                                            (also serves the app over http)
```

## Two parts of this repo

- **Web app** (`index.html`, `styles.css`, `app.js`, `config.js`) - the monitor.
  One panel per boat: connection state (Live / No data / Offline), data rate,
  frames, last-seen, decoded NMEA summary, and the raw stream. A **Settings**
  panel holds each boat's address, saved per device.
- **`bridge/`** - the Node.js server that runs on each boat PC. See
  `bridge/README.md` for its setup.

## Getting it running

1. On **each boat PC**: install Node.js (https://nodejs.org), copy this repo
   over, and run `bridge/start.bat` (double-click). Allow it through the Windows
   firewall on Private networks. It prints the `ws://` and `http://` addresses.
2. In **Expedition** on that PC: Instruments (Ctrl+I) -> new network connection
   -> NMEA 0183 -> UDP to IP address `127.0.0.1` port `5555` -> tick the
   sentences to send. (Details in `bridge/README.md`.)
3. On **any device**: open `http://<a-boat-pc-ip>:8080`, then in **Settings**
   set the two boats to `ws://<boat1-pc-ip>:8080` and `ws://<boat2-pc-ip>:8080`.
   The app connects to both at once.

When both panels read **Live** with a steady rate, the pipeline is proven.

## Adding this to the git repo

I can't push to your GitHub for you (I don't have your credentials), but here's
the whole thing. From inside this folder, if the repo is empty:

```bash
git init
git add .
git commit -m "Boat data receiver: web app + Expedition UDP->WebSocket bridge"
git branch -M main
git remote add origin https://github.com/<owner>/Django-2-boat-testing.git
git push -u origin main
```

If the repo already has a commit, clone it, copy these files in, then
`git add . && git commit && git push`. Replace `<owner>` with whichever of your
two accounts owns the repo. `node_modules/` is gitignored, so each person runs
`npm install` (or just `start.bat`) once on their side.

## Next steps

With the feed proven, the real app builds on the same per-boat WebSocket stream
the browser already receives. Tell me what it should show or compute and we'll
design it from there.
