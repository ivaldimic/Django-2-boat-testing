// Default boats. These are just starting values — each device can override them
// in the Settings panel, and the changes are saved on that device.
//
// Set `url` to the WebSocket endpoint each boat exposes, e.g. "ws://192.168.1.101:8080".
window.DEFAULT_BOATS = [
  { id: "boat1", name: "Boat 1", url: "ws://192.168.1.101:8080" },
  { id: "boat2", name: "Boat 2", url: "ws://192.168.1.102:8080" }
];
